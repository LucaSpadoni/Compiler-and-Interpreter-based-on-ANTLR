package ast;

import semanticanalysis.SemanticError;
import semanticanalysis.SymbolTable;

import java.util.ArrayList;

public class AsgnNode implements Node{

    private Node id;
    private Node right;
    public AsgnNode(Node id, Node right) {
        this.id = id;
        this.right = right;
    }

    @Override
    public ArrayList<SemanticError> checkSemantics(SymbolTable ST, int _nesting) {
        ArrayList<SemanticError> errors = new ArrayList<SemanticError>();
        errors.addAll(right.checkSemantics(ST, _nesting));

        if (ST.lookup(id.toString()) == null)
            errors.add(new SemanticError("Var " + id + " not declared"));

        return errors;
    }

    @Override
    public Type typeCheck() {
        Type typeid = id.typeCheck();

        if (right.typeCheck().getClass().equals(typeid.getClass()))
            return null;
        else {
            System.out.println("Type Error: incompatible type of expression for variable " + id);
            return new ErrorType() ;
        }
    }

    @Override
    public String codeGeneration() {
        return right.codeGeneration() +
                "pushr A0 \n" +
                "load A0 0(FP) \n";
    }

    @Override
    public String toPrint(String s) {
        return s + "Assign\n" + id + " " + right.toPrint(s + "  ");
    }
}
