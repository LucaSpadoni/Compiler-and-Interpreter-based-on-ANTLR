package ast;

import semanticanalysis.SemanticError;
import semanticanalysis.SymbolTable;

import java.util.ArrayList;

public class ParenNode implements Node {
    private Node exp;   // Parenthesis body

    public ParenNode(Node _parbody) {
        exp = _parbody;
    }

    public ArrayList<SemanticError> checkSemantics(SymbolTable ST, int _nesting) {
        ArrayList<SemanticError> errors = new ArrayList<SemanticError>();

        errors.addAll(exp.checkSemantics(ST, _nesting));
        return errors;
    }

    public Type typeCheck() {
        return exp.typeCheck();
    }

    public String codeGeneration() {
        return	exp.codeGeneration();
    }

    public String toPrint(String s) {
        return s + "Parenthesis\n" + exp.toPrint(s + "  ");
    }
}