package ast;

public class BoolType extends Type {
	public String toPrint(String s) {
		return s + "Bool " ;  
	  }

}
