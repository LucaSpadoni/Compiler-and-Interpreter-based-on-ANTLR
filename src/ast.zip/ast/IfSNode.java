package ast;

import semanticanalysis.SemanticError;
import semanticanalysis.SymbolTable;

import java.util.ArrayList;
import java.util.Collection;

public class IfSNode implements Node {
    private Node guard;
    private ArrayList<Node> thenbranch;
    private ArrayList<Node> elsebranch;
    private int nesting;

    public IfSNode (Node _guard, ArrayList<Node> _thenbranch, ArrayList<Node> _elsebranch) {
        guard = _guard ;
        thenbranch = _thenbranch ;
        elsebranch = _elsebranch ;
    }

    @Override
    public ArrayList<SemanticError> checkSemantics(SymbolTable ST, int _nesting) {
        ArrayList<SemanticError> errors = new ArrayList<SemanticError>();
        nesting = _nesting;

        errors.addAll(guard.checkSemantics(ST, nesting));

        for (Node t : thenbranch) {
            errors.addAll(t.checkSemantics(ST, nesting + 1));      // TODO
        }

        for (Node e : elsebranch) {
            errors.addAll(e.checkSemantics(ST, nesting + 1));
        }

        return errors;
    }

    @Override
    public Type typeCheck() {
        ArrayList<Node> thenexp = null;
        ArrayList<Node> elseexp = null;

        if (guard.typeCheck() instanceof BoolType) {
            for (Node t : thenbranch) {
                thenexp.addAll((t.typeCheck()));
            }

            for (Node e : elsebranch) {
                elseexp.addAll((e.typeCheck()));
            }

            if (thenexp.getClass().equals(elseexp.getClass()))
                return thenexp;
            else {
                System.out.println("Type Error: incompatible types in then and else branches");
                return new ErrorType() ;
            }
        }
        else {
            System.out.println("Type Error: non-boolean condition in if");
            return new ErrorType() ;
        }
    }

    @Override
    public String codeGeneration() {
        return null;
    }

    @Override
    public String toPrint(String s) {
        String stmPrint = " ";

        for(Node st : stm){
            stmPrint += st.toPrint(s) + " ";
        }

        return "IfStm "+ stmPrint;
    }
}
