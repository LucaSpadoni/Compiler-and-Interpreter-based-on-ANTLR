package ast;

import evaluator.SimpLanlib;
import semanticanalysis.SemanticError;
import semanticanalysis.SymbolTable;

import java.util.ArrayList;

public class OrNode implements Node{
    private Node left;
    private Node right;
    public OrNode(Node left, Node right) {
        this.left = left;
        this.right = right;
    }

    @Override
    public ArrayList<SemanticError> checkSemantics(SymbolTable ST, int _nesting) {
        ArrayList<SemanticError> errors = new ArrayList<SemanticError>();

        errors.addAll(left.checkSemantics(ST,_nesting));
        errors.addAll(right.checkSemantics(ST,_nesting));

        return errors;
    }
    @Override
    public Type typeCheck() {
        if ((left.typeCheck() instanceof BoolType) && (right.typeCheck() instanceof BoolType))
            return new BoolType() ;
        else {
            System.out.println("Type Error: Non booleans in Or");
            return new ErrorType();
        }
    }

    @Override
    public String codeGeneration() {
        String end = SimpLanlib.freshLabel();
        return left.codeGeneration()+
                "pushr A0 \n" +
                "beq A0 0 " + end + "\n" +
                right.codeGeneration() +
                end + ":\n";
    }

    @Override
    public String toPrint(String s) {
        return s + "Or\n" + left.toPrint(s + "  ") + right.toPrint(s + "  ");
    }
}
