package ast;

public class VoidType extends Type{
	public String toPrint(String s) {
		return s + "Void " ;
	  }

}
