package ast;

import antlr.SimpLanPlusBaseVisitor;
import antlr.SimpLanPlusParser;
import parser.SimpLanParser;

import java.util.ArrayList;
import java.util.Collection;

public class SimpLanPlusVisitorImpl extends SimpLanPlusBaseVisitor<Node> {

	public Node visitSingleExp(SimpLanPlusParser.SingleExpContext ctx) {

		// Simply return the result of the visit to the inner exp
		return new ProgNode(visit(ctx.exp()));
	}

	public Node visitDecStmExp(SimpLanPlusParser.DecStmExpContext ctx) {
		
		// List of declarations in @res
		ArrayList<Node> declarations = new ArrayList<Node>();
		// List of statements in @res
		ArrayList<Node> statements = new ArrayList<Node>();
		// The expression in @res
		Node exp = null;
		
		// Visit all nodes corresponding to declarations inside the context and store them in @declarations, the same
		// for the statements. Notice that the ctx.dec() method returns a list, this is because of the use of * or +
		// in the grammar antlr detects this is a group and therefore returns a list
		for (SimpLanPlusParser.DecContext dc : ctx.dec()){
			declarations.add(visit(dc));
		}

		for (SimpLanPlusParser.StmContext sc : ctx.stm()){
			statements.add(visit(sc));
		}

		// Visit exp context if there's one
		if (ctx.exp() != null)
			exp = visit(ctx.exp());
		
		// Build @res accordingly with the result of the visits to its content
		return new ProgDecStmNode(declarations, statements, exp);
	}
	
	public Node visitIdDec(SimpLanPlusParser.IdDecContext ctx) {
		// Visit the type
		Node typeNode = visit(ctx.type());
		
		// Build the varNode
		return new DecNode(ctx.ID().getText(), typeNode);
	}
	
	public Node visitFunDec(SimpLanPlusParser.FunDecContext ctx) {
		//initialize @res with the visits to the type and its ID
		//add argument declarations
		//we are getting a shortcut here by constructing directly the ParNode
		//this could be done differently by visiting instead the VardecContext
		ArrayList<ParNode> _param = new ArrayList<ParNode>();
				
		for (SimpLanPlusParser.ParamContext vc : ctx.param())
			_param.add(new ParNode(vc.ID().getText(), (Type) visit(vc.type())));

		//add body
		//create a list for the nested declarations
		ArrayList<Node> innerDec = new ArrayList<Node>();
		
		// Check whether there are actually nested decs
		for (SimpLanPlusParser.DecContext dc : ctx.body().dec())
			innerDec.add(visit(dc));

		// Visit the body of the function
		Node body = visitBody(ctx.body());
		
		return new FunNode(ctx.ID().getText(), (Type) visit(ctx.type()), _param, innerDec, body);
	}

	public Node visitBody(SimpLanPlusParser.BodyContext ctx) {
		// List of declarations in @res
		ArrayList<Node> declarations = new ArrayList<Node>();
		// List of statements in @res
		ArrayList<Node> statements = new ArrayList<Node>();
		// The expression in @res
		Node exp = null;

		// Visit all nodes corresponding to declarations inside the context and store them in @declarations, the same
		// for the statements. Notice that the ctx.dec() method returns a list, this is because of the use of * or +
		// in the grammar antlr detects this is a group and therefore returns a list
		for (SimpLanPlusParser.DecContext dc : ctx.dec()){
			declarations.add(visit(dc));
		}

		for (SimpLanPlusParser.StmContext sc : ctx.stm()){
			statements.add(visit(sc));
		}

		// Visit exp context if there's one
		if (ctx.exp() != null)
			exp = visit(ctx.exp());

		return new BodyNode(declarations, statements, exp);
	}

	public Node visitType(SimpLanPlusParser.TypeContext ctx) {
		if (ctx.getText().equals("int"))
			return new IntType();
		else if (ctx.getText().equals("bool"))
			return new BoolType();
		else return new VoidType();
	}
	// Integer.parseInt(ctx.INTEGER().getText())

	public Node visitIdInit(SimpLanPlusParser.IdInitContext ctx) {
		// Visit the exp
		Node exp = visit(ctx.exp());

		return new AsgnNode((Node) ctx.ID(), exp); // Casting because ID() is a terminal node
	}

	public Node visitFunStm(SimpLanPlusParser.FunStmContext ctx) {	// This corresponds to a function invocation
		// Get the invocation arguments
		ArrayList<Node> args = new ArrayList<Node>();

		for (SimpLanPlusParser.ExpContext exp : ctx.exp())
			args.add(visit(exp));

		return new CallNode(ctx.ID().getText(), args);
	}

	public Node visitIfStm(SimpLanPlusParser.IfStmContext ctx) {
		//visit the conditional, then the then branch, and then the else branch
		//notice once again the need of named terminals in the rule, this is because
		//we need to point to the right expression among the 3 possible ones in the rule

		Node condExp = visit(ctx.cond);
		ArrayList<Node> thenExp;

		for (SimpLanPlusParser.IfStmContext sc : ctx.thenBranch.stm()){
			thenExp.add(visit(sc));
		}
				= visit(ctx.thenBranch);

		ArrayList<Node> elseExp = visit(ctx.elseBranch);

		return new IfSNode(condExp, thenExp, elseExp);
	}

	public Node visitCompareExp(SimpLanPlusParser.CompareExpContext ctx) {
		if (ctx.right == null){ //it is a simple expression
			return visit( ctx.left );
		}
		else{ //it is a binary expression, you should visit left and right
			return new EqualNode(visit(ctx.left), visit(ctx.right));
		}
	}

	public Node visitVarExp(SimpLanPlusParser.VarExpContext ctx) {
		//this corresponds to a variable access
		return new IdNode(ctx.ID().getText());
	}

	public Node visitAndOrExp(SimpLanPlusParser.AndOrExpContext ctx) {
		//there is no need to perform a check here, the lexer ensures this text is a boolean
		return new AndNode();
		return new OrNode();
	}

	public Node visitTrueExp(SimpLanPlusParser.TrueExpContext ctx) {
		//there is no need to perform a check here, the lexer ensures this text is a boolean
		return new BoolNode();
	}

	public Node visitMulDivExp(SimpLanPlusParser.MulDivExpContext ctx) {
		if(ctx.right == null){ //it is a simple expression
			return visit( ctx.left );
		} else {
			//it is a binary expression: visit left and right
			if(ctx.mul != null)
				return new MultNode(visit(ctx.left), visit(ctx.right));
			else return new DivNode(visit(ctx.left), visit(ctx.right));
		}
	}

	public Node visitParExp(SimpLanPlusParser.ParExpContext ctx) {

		//this is actually nothing in the sense that for the ast the parenthesis are not relevant
		//the thing is that the structure of the ast will ensure the operational order by giving
		//a larger depth (closer to the leafs) to those expressions with higher importance

		//this is actually the default implementation for this method in the SimpLanBaseVisitor class
		//therefore it can be safely removed here

		return visit (ctx.exp()); //ParenNode
	}

	public Node visitIfExp(SimpLanPlusParser.IfExpContext ctx) {
		//visit the conditional, then the then branch, and then the else branch
		//notice once again the need of named terminals in the rule, this is because
		//we need to point to the right expression among the 3 possible ones in the rule

		Node condExp = visit (ctx.cond);

		Node thenExp = visit (ctx.thenBranch);

		Node elseExp = visit (ctx.elseBranch);

		return new IfENode(condExp, thenExp, elseExp);
	}

	public Node visitSumSubExp(SimpLanPlusParser.SumSubExpContext ctx) {
		if(ctx.right == null){ //it is a simple expression
			return visit( ctx.left );
		} else {
			//it is a binary expression: visit left and right
			if(ctx.mul != null)
				return new PlusNode(visit(ctx.left), visit(ctx.right));
			else return new MinusNode(visit(ctx.left), visit(ctx.right));
		}
	}

	public Node visitFalseExp(SimpLanPlusParser.FalseExpContext ctx) {
		//there is no need to perform a check here, the lexer ensures this text is a boolean
		return new BoolNode();
	}

	public Node visitFunExp(SimpLanPlusParser.FunExpContext ctx) {
		// Get the invocation arguments
		ArrayList<Node> args = new ArrayList<Node>();

		for (SimpLanPlusParser.ExpContext exp : ctx.exp())
			args.add(visit(exp));

		return new CallNode(ctx.ID().getText(), args);
	}

	public Node visitFalseExp(SimpLanPlusParser.FalseExpContext ctx) {
		//there is no need to perform a check here, the lexer ensures this text is a boolean
		return new BoolNode();
	}
	
	public Node visitNotExp(SimpLanPlusParser.NotExpContext ctx) {

		return new NotNode();
	}
	
	public Node visitIntExp(SimpLanPlusParser.IntExpContext ctx) {
		return new IntType();
	}
